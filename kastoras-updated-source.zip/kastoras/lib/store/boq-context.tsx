'use client';

import React, { createContext, useContext, useState } from 'react';
import { BOQ } from '../types/boq';

interface BOQContextType {
  boqs: BOQ[];
  getBOQById: (id: string) => BOQ | undefined;
  getBOQsByEstimateId: (estimateId: string) => BOQ[];
  saveBOQ: (boq: BOQ) => BOQ;
  deleteBOQ: (id: string) => void;
  isLoading: boolean;
}

const BOQContext = createContext<BOQContextType | undefined>(undefined);

const STORAGE_KEY = 'kastoras_boqs_v1';

function getStoredBOQs(): BOQ[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch (e) {
    console.error('Failed to load BOQs from localStorage:', e);
    return [];
  }
}

export function BOQProvider({ children }: { children: React.ReactNode }) {
  const [boqs, setBOQs] = useState<BOQ[]>(getStoredBOQs);

  const syncWithLocalStorage = (newBOQs: BOQ[]) => {
    setBOQs(newBOQs);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newBOQs));
      } catch (e) {
        console.error('Failed to save BOQs to localStorage:', e);
      }
    }
  };

  const saveBOQ = (boq: BOQ): BOQ => {
    const updated = [boq, ...boqs.filter((b) => b.id !== boq.id)];
    syncWithLocalStorage(updated);
    return boq;
  };

  const getBOQById = (id: string) => boqs.find((b) => b.id === id);

  const getBOQsByEstimateId = (estimateId: string) =>
    boqs.filter((b) => b.estimateId === estimateId);

  const deleteBOQ = (id: string) => {
    syncWithLocalStorage(boqs.filter((b) => b.id !== id));
  };

  return (
    <BOQContext.Provider
      value={{ boqs, getBOQById, getBOQsByEstimateId, saveBOQ, deleteBOQ, isLoading: false }}
    >
      {children}
    </BOQContext.Provider>
  );
}

export function useBOQs() {
  const context = useContext(BOQContext);
  if (!context) {
    throw new Error('useBOQs must be used within a BOQProvider');
  }
  return context;
}
