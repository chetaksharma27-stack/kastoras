'use client';

import React, { createContext, useContext, useState } from 'react';
import { CarbonAnalysis } from '../types/carbon';

interface CarbonContextType {
  analyses: CarbonAnalysis[];
  getAnalysisById: (id: string) => CarbonAnalysis | undefined;
  getAnalysesByBOQId: (boqId: string) => CarbonAnalysis[];
  saveAnalysis: (analysis: CarbonAnalysis) => CarbonAnalysis;
  deleteAnalysis: (id: string) => void;
  isLoading: boolean;
}

const CarbonContext = createContext<CarbonContextType | undefined>(undefined);

const STORAGE_KEY = 'kastoras_carbon_v1';

function getStoredAnalyses(): CarbonAnalysis[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch (e) {
    console.error('Failed to load carbon analyses from localStorage:', e);
    return [];
  }
}

export function CarbonProvider({ children }: { children: React.ReactNode }) {
  const [analyses, setAnalyses] = useState<CarbonAnalysis[]>(getStoredAnalyses);

  const syncWithLocalStorage = (newAnalyses: CarbonAnalysis[]) => {
    setAnalyses(newAnalyses);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newAnalyses));
      } catch (e) {
        console.error('Failed to save carbon analyses to localStorage:', e);
      }
    }
  };

  const saveAnalysis = (analysis: CarbonAnalysis): CarbonAnalysis => {
    const updated = [analysis, ...analyses.filter((a) => a.id !== analysis.id)];
    syncWithLocalStorage(updated);
    return analysis;
  };

  const getAnalysisById = (id: string) => analyses.find((a) => a.id === id);

  const getAnalysesByBOQId = (boqId: string) => analyses.filter((a) => a.boqId === boqId);

  const deleteAnalysis = (id: string) => {
    syncWithLocalStorage(analyses.filter((a) => a.id !== id));
  };

  return (
    <CarbonContext.Provider
      value={{
        analyses,
        getAnalysisById,
        getAnalysesByBOQId,
        saveAnalysis,
        deleteAnalysis,
        isLoading: false,
      }}
    >
      {children}
    </CarbonContext.Provider>
  );
}

export function useCarbonAnalyses() {
  const context = useContext(CarbonContext);
  if (!context) {
    throw new Error('useCarbonAnalyses must be used within a CarbonProvider');
  }
  return context;
}
