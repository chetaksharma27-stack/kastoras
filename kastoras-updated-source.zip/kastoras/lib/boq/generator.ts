import { Estimate, EstimateCategory } from '../types/estimation';
import { BOQ, BOQItem, BOQTrade, SteelSummaryLine } from '../types/boq';

function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Maps each internal estimation category to the standard IS 1200 measurement
 * code part it corresponds to, and the BOQ trade grouping it should sit under.
 */
const CATEGORY_TO_BOQ: Record<EstimateCategory, { trade: BOQTrade; isCode: string }> = {
  'Substructure & Earthwork': { trade: 'Earthwork', isCode: 'IS 1200 : Part 1' },
  'RCC & Structural Framework': { trade: 'RCC', isCode: 'IS 1200 : Part 2' },
  'Masonry & Superstructure': { trade: 'Masonry', isCode: 'IS 1200 : Part 3' },
  'Waterproofing & Plastering': { trade: 'Waterproofing & Plastering', isCode: 'IS 1200 : Part 12' },
  'Flooring & Tiling': { trade: 'Flooring', isCode: 'IS 1200 : Part 11' },
  'Doors & Windows': { trade: 'Doors & Windows', isCode: 'IS 1200 : Part 5 / 23' },
  'Plumbing & Sanitary': { trade: 'MEP', isCode: 'IS 1200 : Part 16' },
  'Electrical Infrastructure': { trade: 'MEP', isCode: 'IS 1200 : Part 15' },
  'Painting & Surface Finishes': { trade: 'Painting', isCode: 'IS 1200 : Part 13' },
  'Site Overheads & Supervision': { trade: 'MEP', isCode: 'IS 1200 : Part 1' },
};

/**
 * Generates a structured, trade-grouped Bill of Quantities from an already
 * calculated cost estimate. Quantities and item descriptions are carried
 * forward as-is (they are the authoritative takeoff); the BOQ view groups
 * them under standard IS 1200 measurement code taxonomy instead of the
 * material/labour/equipment rate breakdown used in the cost estimate.
 */
export function generateBOQFromEstimate(estimate: Estimate, boqName?: string): BOQ {
  const boqId = generateUUID();

  const items: BOQItem[] = estimate.items.map((estItem) => {
    const mapping = CATEGORY_TO_BOQ[estItem.category] || {
      trade: 'MEP' as BOQTrade,
      isCode: 'IS 1200',
    };

    return {
      id: generateUUID(),
      boqId,
      trade: mapping.trade,
      isCode: mapping.isCode,
      itemCode: estItem.itemCode,
      description: estItem.description,
      unit: estItem.unit,
      quantity: estItem.quantity,
      rate: estItem.totalRate,
      amount: estItem.amount,
    };
  });

  // Bar Bending / Steel Summary: separates reinforcement rebar (RCC-002) from
  // fabricated structural steel sections (STL-001) - these are two different
  // materials with different rates and must never be combined into one line.
  const steelSummary: SteelSummaryLine[] = estimate.items
    .filter((i) => i.itemCode === 'RCC-002' || i.itemCode === 'STL-001')
    .map((i) => ({
      itemCode: i.itemCode,
      description: i.description,
      quantityMT: i.quantity,
      amount: i.amount,
    }));

  const totalAmount = items.reduce((sum, i) => sum + i.amount, 0);

  const now = new Date().toISOString();

  return {
    id: boqId,
    estimateId: estimate.id,
    projectId: estimate.projectId,
    projectName: estimate.projectName,
    clientName: estimate.clientName,
    location: estimate.location,
    boqName: boqName || `BOQ: ${estimate.projectName}`,
    measurementCode: 'IS 1200 / CPWD',
    totalBuiltUpArea: estimate.totalBuiltUpArea,
    items,
    steelSummary,
    totalAmount: Math.round(totalAmount),
    createdAt: now,
    updatedAt: now,
  };
}
