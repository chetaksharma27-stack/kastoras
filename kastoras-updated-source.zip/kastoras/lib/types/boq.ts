export type BOQTrade =
  | 'Earthwork'
  | 'RCC'
  | 'Masonry'
  | 'Waterproofing & Plastering'
  | 'Flooring'
  | 'Doors & Windows'
  | 'MEP'
  | 'Painting';

export interface BOQItem {
  id: string;
  boqId: string;
  trade: BOQTrade;
  isCode: string; // Reference measurement code part (IS 1200)
  itemCode: string;
  description: string;
  unit: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface SteelSummaryLine {
  itemCode: string;
  description: string;
  quantityMT: number;
  amount: number;
}

export interface BOQ {
  id: string;
  estimateId: string;
  projectId: string;
  projectName: string;
  clientName: string;
  location: string;
  boqName: string;
  measurementCode: string;
  totalBuiltUpArea: number;
  items: BOQItem[];
  steelSummary: SteelSummaryLine[];
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
}
