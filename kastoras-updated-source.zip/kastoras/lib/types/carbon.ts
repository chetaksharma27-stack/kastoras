export interface CarbonLineItem {
  id: string;
  itemCode: string;
  trade: string;
  description: string;
  quantity: number;
  unit: string;
  emissionFactor: number;
  emissionFactorUnit: string;
  totalEmissionsKg: number;
  excluded: boolean;
  exclusionReason?: string;
}

export interface TradeCarbonBreakdown {
  trade: string;
  kgCO2e: number;
  percent: number;
}

export interface CarbonAnalysis {
  id: string;
  boqId: string;
  estimateId: string;
  projectId: string;
  projectName: string;
  location: string;
  analysisName: string;
  totalBuiltUpAreaSqft: number;
  totalBuiltUpAreaSqm: number;
  items: CarbonLineItem[];
  totalEmbodiedCarbonKg: number;
  totalEmbodiedCarbonTonnes: number;
  carbonIntensityKgPerSqm: number;
  tradeBreakdown: TradeCarbonBreakdown[];
  createdAt: string;
  updatedAt: string;
}
