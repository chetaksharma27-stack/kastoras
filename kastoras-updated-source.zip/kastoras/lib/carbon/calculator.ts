import { BOQ } from '../types/boq';
import { CarbonAnalysis, CarbonLineItem, TradeCarbonBreakdown } from '../types/carbon';
import { getEmissionFactor } from './emission-factors';

function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

const SQFT_TO_SQM = 0.0929;

/**
 * Calculates embodied carbon (Stages A1-A3, cradle-to-gate) from a generated
 * BOQ's material quantities, using the emission factor database. Items with
 * unit 'MT' (reinforcement rebar, structural steel) are converted to kg
 * before applying their per-kg emission factor - the same unit discipline
 * that fixed the cost calculation bug applies here too.
 */
export function calculateEmbodiedCarbon(boq: BOQ, analysisName?: string): CarbonAnalysis {
  const analysisId = generateUUID();

  const items: CarbonLineItem[] = boq.items.map((boqItem) => {
    const ef = getEmissionFactor(boqItem.itemCode);

    if (!ef) {
      return {
        id: generateUUID(),
        itemCode: boqItem.itemCode,
        trade: boqItem.trade,
        description: boqItem.description,
        quantity: boqItem.quantity,
        unit: boqItem.unit,
        emissionFactor: 0,
        emissionFactorUnit: '-',
        totalEmissionsKg: 0,
        excluded: true,
        exclusionReason: 'No emission factor available for this item',
      };
    }

    let totalEmissionsKg: number;
    let emissionFactorUnit: string;

    if (ef.perKg) {
      // Quantity is in MT (metric tonnes) for rebar/structural steel - convert to kg first.
      const weightKg = boqItem.unit === 'MT' ? boqItem.quantity * 1000 : boqItem.quantity;
      totalEmissionsKg = weightKg * ef.factor;
      emissionFactorUnit = 'kgCO2e/kg';
    } else {
      totalEmissionsKg = boqItem.quantity * ef.factor;
      emissionFactorUnit = `kgCO2e/${boqItem.unit}`;
    }

    return {
      id: generateUUID(),
      itemCode: boqItem.itemCode,
      trade: boqItem.trade,
      description: boqItem.description,
      quantity: boqItem.quantity,
      unit: boqItem.unit,
      emissionFactor: ef.factor,
      emissionFactorUnit,
      totalEmissionsKg: Math.round(totalEmissionsKg * 100) / 100,
      excluded: false,
    };
  });

  const totalEmbodiedCarbonKg = Math.round(
    items.reduce((sum, i) => sum + i.totalEmissionsKg, 0)
  );
  const totalEmbodiedCarbonTonnes = Math.round((totalEmbodiedCarbonKg / 1000) * 100) / 100;

  const totalBuiltUpAreaSqm = Math.round(boq.totalBuiltUpArea * SQFT_TO_SQM * 100) / 100;
  const carbonIntensityKgPerSqm =
    totalBuiltUpAreaSqm > 0
      ? Math.round((totalEmbodiedCarbonKg / totalBuiltUpAreaSqm) * 100) / 100
      : 0;

  const tradeTotals: Record<string, number> = {};
  items.forEach((i) => {
    if (i.excluded) return;
    tradeTotals[i.trade] = (tradeTotals[i.trade] || 0) + i.totalEmissionsKg;
  });

  const tradeBreakdown: TradeCarbonBreakdown[] = Object.entries(tradeTotals)
    .map(([trade, kgCO2e]) => ({
      trade,
      kgCO2e: Math.round(kgCO2e),
      percent: Math.round((kgCO2e / Math.max(1, totalEmbodiedCarbonKg)) * 100),
    }))
    .sort((a, b) => b.kgCO2e - a.kgCO2e);

  const now = new Date().toISOString();

  return {
    id: analysisId,
    boqId: boq.id,
    estimateId: boq.estimateId,
    projectId: boq.projectId,
    projectName: boq.projectName,
    location: boq.location,
    analysisName: analysisName || `Carbon Analysis: ${boq.projectName}`,
    totalBuiltUpAreaSqft: boq.totalBuiltUpArea,
    totalBuiltUpAreaSqm,
    items,
    totalEmbodiedCarbonKg,
    totalEmbodiedCarbonTonnes,
    carbonIntensityKgPerSqm,
    tradeBreakdown,
    createdAt: now,
    updatedAt: now,
  };
}
