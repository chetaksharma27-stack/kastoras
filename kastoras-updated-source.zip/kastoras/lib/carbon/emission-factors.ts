export interface EmissionFactor {
  itemCode: string;
  materialName: string;
  /** kgCO2e per the item's own BOQ unit (e.g. per cum, per sqm, per kg, per set) */
  factor: number;
  /** true if the factor is expressed per kg of material rather than per BOQ unit
   *  (used for items whose BOQ unit is MT - reinforcement & structural steel) */
  perKg: boolean;
  source: string;
}

/**
 * Illustrative/MVP embodied carbon factors (Stages A1-A3, cradle-to-gate),
 * approximated from published benchmarks (ICE Database v3 / EC3 style figures).
 * These should be replaced with region-specific EPDs for compliance-grade reporting.
 */
export const EMISSION_FACTORS: Record<string, EmissionFactor> = {
  'EW-001': { itemCode: 'EW-001', materialName: 'Excavation (diesel plant)', factor: 5, perKg: false, source: 'Illustrative/MVP factor' },
  'EW-002': { itemCode: 'EW-002', materialName: 'PCC 1:4:8 (lean concrete)', factor: 180, perKg: false, source: 'Illustrative/MVP factor' },
  'EW-003': { itemCode: 'EW-003', materialName: 'Anti-termite treatment', factor: 1.2, perKg: false, source: 'Illustrative/MVP factor' },

  'RCC-001': { itemCode: 'RCC-001', materialName: 'M25 RCC (footings/beams/slabs)', factor: 310, perKg: false, source: 'Illustrative/MVP factor' },
  'RCC-002': { itemCode: 'RCC-002', materialName: 'TMT Fe500D reinforcement rebar', factor: 1.99, perKg: true, source: 'Illustrative/MVP factor' },
  // RCC-003 (shuttering/formwork) intentionally excluded - temporary works, reused across pours.
  'STL-001': { itemCode: 'STL-001', materialName: 'Fabricated structural steel sections', factor: 2.75, perKg: true, source: 'Illustrative/MVP factor' },

  'MAS-001': { itemCode: 'MAS-001', materialName: 'Clay brick masonry (1:6 mortar)', factor: 220, perKg: false, source: 'Illustrative/MVP factor' },
  'MAS-002': { itemCode: 'MAS-002', materialName: 'AAC block masonry', factor: 110, perKg: false, source: 'Illustrative/MVP factor' },

  'FIN-001': { itemCode: 'FIN-001', materialName: 'Internal cement plaster', factor: 4, perKg: false, source: 'Illustrative/MVP factor' },
  'FIN-002': { itemCode: 'FIN-002', materialName: 'External cement plaster', factor: 5, perKg: false, source: 'Illustrative/MVP factor' },
  'FIN-003': { itemCode: 'FIN-003', materialName: 'Polymer membrane waterproofing', factor: 3, perKg: false, source: 'Illustrative/MVP factor' },

  'FLR-001': { itemCode: 'FLR-001', materialName: 'Vitrified tile flooring', factor: 14, perKg: false, source: 'Illustrative/MVP factor' },
  'FLR-002': { itemCode: 'FLR-002', materialName: 'Granite flooring', factor: 20, perKg: false, source: 'Illustrative/MVP factor' },

  'OPN-001': { itemCode: 'OPN-001', materialName: 'Hardwood doors', factor: 40, perKg: false, source: 'Illustrative/MVP factor' },
  'OPN-002': { itemCode: 'OPN-002', materialName: 'UPVC/aluminium glazed windows', factor: 55, perKg: false, source: 'Illustrative/MVP factor' },

  'MEP-P01': { itemCode: 'MEP-P01', materialName: 'CPVC/PVC plumbing pipework', factor: 1.2, perKg: false, source: 'Illustrative/MVP factor' },
  'MEP-P02': { itemCode: 'MEP-P02', materialName: 'Sanitary fixtures', factor: 45, perKg: false, source: 'Illustrative/MVP factor' },
  'MEP-E01': { itemCode: 'MEP-E01', materialName: 'Copper wiring & switchgear', factor: 1.0, perKg: false, source: 'Illustrative/MVP factor' },

  'PNT-001': { itemCode: 'PNT-001', materialName: 'Internal acrylic emulsion paint', factor: 1.5, perKg: false, source: 'Illustrative/MVP factor' },
  'PNT-002': { itemCode: 'PNT-002', materialName: 'External weatherproof paint', factor: 1.8, perKg: false, source: 'Illustrative/MVP factor' },
};

export function getEmissionFactor(itemCode: string): EmissionFactor | undefined {
  return EMISSION_FACTORS[itemCode];
}
