'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useBOQs } from '../../lib/store/boq-context';
import { ArrowLeft, MapPin, Calendar, Printer, Info, Ruler } from 'lucide-react';

interface BOQResultsViewProps {
  id: string;
}

export function BOQResultsView({ id }: BOQResultsViewProps) {
  const { getBOQById } = useBOQs();
  const [selectedTrade, setSelectedTrade] = useState<string>('ALL');

  const boq = getBOQById(id);

  if (!boq) {
    return (
      <Card className="p-12 text-center bg-white border-slate-200 max-w-2xl mx-auto">
        <h2 className="text-lg font-bold text-slate-900">BOQ Not Found</h2>
        <p className="text-xs text-slate-500 mt-1">
          The requested BOQ identifier was not found in your workspace.
        </p>
        <div className="mt-4">
          <Link href="/boq">
            <Button variant="outline" size="sm" icon={<ArrowLeft className="w-4 h-4" />}>
              Back to BOQs
            </Button>
          </Link>
        </div>
      </Card>
    );
  }

  const trades = Array.from(new Set(boq.items.map((i) => i.trade)));
  const filteredItems =
    selectedTrade === 'ALL' ? boq.items : boq.items.filter((i) => i.trade === selectedTrade);

  const tradeTotals: Record<string, number> = {};
  boq.items.forEach((i) => {
    tradeTotals[i.trade] = (tradeTotals[i.trade] || 0) + i.amount;
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16 print:p-0 print:max-w-none">
      {/* Top bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 print:hidden">
        <div className="flex items-center gap-3">
          <Link
            href="/boq"
            className="text-xs text-slate-500 hover:text-slate-900 flex items-center gap-1.5 transition-colors font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All BOQs</span>
          </Link>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => window.print()}
          icon={<Printer className="w-3.5 h-3.5" />}
        >
          Print BOQ
        </Button>
      </div>

      {/* Header */}
      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
                M2
              </span>
              <Badge variant="blue" className="font-mono text-xs">
                Bill of Quantities · {boq.measurementCode}
              </Badge>
              <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {new Date(boq.createdAt).toLocaleDateString()}
              </span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{boq.boqName}</h1>
            <div className="flex flex-wrap items-center gap-4 mt-2 text-xs text-slate-600">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{boq.location}</span>
              </span>
              <span className="font-mono text-slate-400">
                Built-up:{' '}
                <strong className="text-slate-900">
                  {boq.totalBuiltUpArea.toLocaleString()} sq.ft
                </strong>
              </span>
            </div>
          </div>

          <div className="p-4 bg-slate-900 text-white rounded-xl text-left md:text-right shrink-0 border border-slate-800">
            <span className="text-[10px] font-mono text-blue-400 uppercase tracking-wider block font-semibold">
              Total BOQ Value
            </span>
            <span className="text-2xl sm:text-3xl font-bold font-mono text-white block mt-0.5">
              ₹{boq.totalAmount.toLocaleString()}
            </span>
            <span className="text-xs font-mono text-blue-300 block mt-1">
              {boq.items.length} <span className="text-slate-400">line items</span>
            </span>
          </div>
        </div>
      </Card>

      {/* Steel Summary (Bar Bending / Structural Steel Schedule) */}
      {boq.steelSummary.length > 0 && (
        <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
            <Ruler className="w-4 h-4 text-blue-600" />
            <h2 className="text-base font-bold text-slate-900">Steel Schedule Summary</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {boq.steelSummary.map((s) => (
              <div key={s.itemCode} className="p-4 rounded-lg border border-slate-200 bg-slate-50/60">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-500">{s.itemCode}</span>
                  <span className="font-mono text-sm font-bold text-slate-900">
                    {s.quantityMT.toLocaleString()} MT
                  </span>
                </div>
                <p className="text-xs text-slate-700 mt-1.5 leading-snug">{s.description}</p>
                <p className="text-xs font-mono text-slate-500 mt-2">
                  ₹{s.amount.toLocaleString()}
                </p>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 mt-3 leading-relaxed">
            Reinforcement rebar (RCC-002) and fabricated structural steel sections (STL-001) are kept as separate line items throughout - they use different unit weights, rates, and takeoff logic.
          </p>
        </Card>
      )}

      {/* Trade Filter + Table */}
      <Card className="overflow-hidden bg-white border-slate-200/90 shadow-2xs">
        <div className="p-4 border-b border-slate-100 flex flex-wrap gap-2 print:hidden">
          <button
            onClick={() => setSelectedTrade('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              selectedTrade === 'ALL'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
            }`}
          >
            All Trades ({boq.items.length})
          </button>
          {trades.map((t) => (
            <button
              key={t}
              onClick={() => setSelectedTrade(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                selectedTrade === t
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
              }`}
            >
              {t} ({boq.items.filter((i) => i.trade === t).length})
            </button>
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-mono text-slate-600 uppercase tracking-wider">
                <th className="py-3 px-3 font-semibold">Trade / IS Code</th>
                <th className="py-3 px-3 font-semibold">Item Code</th>
                <th className="py-3 px-3 font-semibold">Description</th>
                <th className="py-3 px-3 font-semibold text-center">Unit</th>
                <th className="py-3 px-3 font-semibold text-right">Quantity</th>
                <th className="py-3 px-3 font-semibold text-right">Rate</th>
                <th className="py-3 px-3 font-semibold text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2.5 px-3">
                    <span className="block text-slate-800 font-medium">{item.trade}</span>
                    <span className="block text-[10px] font-mono text-slate-400">{item.isCode}</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-700">
                    {item.itemCode}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-900 max-w-[260px]">
                    {item.description}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-slate-500">{item.unit}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-800">
                    {item.quantity.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-500">
                    ₹{item.rate.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                    ₹{item.amount.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-900 text-white font-mono font-bold text-sm">
                <td colSpan={6} className="py-3 px-3 uppercase tracking-wider">
                  Total BOQ Value
                </td>
                <td className="py-3 px-3 text-right text-blue-300">
                  ₹{boq.totalAmount.toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      {/* Trade breakdown */}
      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
          <Info className="w-5 h-5 text-blue-600" />
          <h2 className="text-base font-bold text-slate-900">Trade-wise Value Breakdown</h2>
        </div>
        <div className="space-y-2.5">
          {Object.entries(tradeTotals)
            .sort((a, b) => b[1] - a[1])
            .map(([trade, amount]) => {
              const pct = Math.round((amount / Math.max(1, boq.totalAmount)) * 100);
              return (
                <div key={trade}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-medium text-slate-700">{trade}</span>
                    <span className="font-mono text-slate-500">
                      ₹{amount.toLocaleString()} ({pct}%)
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
        </div>
      </Card>
    </div>
  );
}
