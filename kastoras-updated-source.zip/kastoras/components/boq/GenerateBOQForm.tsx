'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useEstimates } from '../../lib/store/estimation-context';
import { useBOQs } from '../../lib/store/boq-context';
import { generateBOQFromEstimate } from '../../lib/boq/generator';
import { ArrowLeft, Layers, MapPin, Calculator } from 'lucide-react';

export function GenerateBOQForm() {
  const router = useRouter();
  const { estimates } = useEstimates();
  const { saveBOQ } = useBOQs();
  const [selectedEstimateId, setSelectedEstimateId] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const selectedEstimate = estimates.find((e) => e.id === selectedEstimateId);

  const handleGenerate = () => {
    if (!selectedEstimate) return;
    setIsGenerating(true);
    const boq = generateBOQFromEstimate(selectedEstimate);
    saveBOQ(boq);
    router.push(`/boq/${boq.id}`);
  };

  if (estimates.length === 0) {
    return (
      <Card className="p-12 text-center bg-white border-slate-200 max-w-2xl mx-auto border-dashed">
        <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-4 mx-auto shadow-2xs">
          <Calculator className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-slate-900">No Cost Estimates Yet</h2>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
          BOQs are extracted from an existing cost estimate&apos;s quantity takeoff. Generate a Module 1 cost estimate first.
        </p>
        <div className="mt-5">
          <Link href="/estimates/new">
            <Button variant="amber" size="sm">
              Create Cost Estimate
            </Button>
          </Link>
        </div>
      </Card>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16">
      <div className="flex items-center gap-3 pb-3 border-b border-slate-200">
        <Link
          href="/boq"
          className="text-xs text-slate-500 hover:text-slate-900 flex items-center gap-1.5 transition-colors font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>All BOQs</span>
        </Link>
      </div>

      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
            M2
          </span>
          <Badge variant="blue" className="font-mono text-xs">
            Generate Bill of Quantities
          </Badge>
        </div>
        <h1 className="text-xl font-bold text-slate-900 mt-2">
          Select a Cost Estimate to Extract
        </h1>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">
          The BOQ inherits the quantity takeoff already calculated in the estimate, and regroups every line item under standard IS 1200 / CPWD trade categories.
        </p>

        <div className="mt-5 space-y-2 max-h-80 overflow-y-auto pr-1">
          {estimates.map((est) => (
            <button
              key={est.id}
              type="button"
              onClick={() => setSelectedEstimateId(est.id)}
              className={`w-full text-left p-4 rounded-lg border transition-colors ${
                selectedEstimateId === est.id
                  ? 'border-blue-400 bg-blue-50/60 ring-2 ring-blue-500/20'
                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-bold text-slate-900">{est.estimateName}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">Project: {est.projectName}</p>
                  <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-500">
                    <MapPin className="w-3 h-3" />
                    <span>{est.location}</span>
                    <span className="text-slate-300">•</span>
                    <span className="font-mono">{est.items.length} items</span>
                  </div>
                </div>
                <span className="font-mono text-sm font-bold text-slate-900 shrink-0">
                  ₹{est.totalEstimatedCost.toLocaleString()}
                </span>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100">
          <Button
            variant="primary"
            size="md"
            className="w-full font-semibold"
            icon={<Layers className="w-4 h-4" />}
            disabled={!selectedEstimateId || isGenerating}
            onClick={handleGenerate}
          >
            {isGenerating ? 'Generating BOQ...' : 'Generate Bill of Quantities'}
          </Button>
        </div>
      </Card>
    </div>
  );
}
