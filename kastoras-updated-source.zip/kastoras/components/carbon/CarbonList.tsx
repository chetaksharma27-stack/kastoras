'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useCarbonAnalyses } from '../../lib/store/carbon-context';
import { useBOQs } from '../../lib/store/boq-context';
import { Leaf, Plus, Search, MapPin, ArrowUpRight, Trash2 } from 'lucide-react';

export function CarbonList() {
  const { analyses, deleteAnalysis } = useCarbonAnalyses();
  const { boqs } = useBOQs();
  const [search, setSearch] = useState('');

  const filtered = analyses.filter((a) => {
    return (
      a.analysisName.toLowerCase().includes(search.toLowerCase()) ||
      a.projectName.toLowerCase().includes(search.toLowerCase()) ||
      a.location.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
              M3
            </span>
            <Badge variant="emerald" className="font-mono text-xs">
              Carbon Footprint &amp; LCA Analysis
            </Badge>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Embodied Carbon Analyses
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Upfront embodied carbon (Stages A1-A3) calculated from your BOQ material quantities and emission factors.
          </p>
        </div>

        <Link href="/carbon/new">
          <Button
            variant="secondary"
            size="md"
            icon={<Plus className="w-4 h-4" />}
            className="font-semibold shadow-xs bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700"
          >
            + New Carbon Analysis
          </Button>
        </Link>
      </div>

      {/* Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search analyses by name, project, location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400 shadow-2xs"
          />
        </div>
        <div className="text-xs font-mono text-slate-500">
          {filtered.length} {filtered.length === 1 ? 'analysis' : 'analyses'} found
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card className="p-12 text-center bg-white border-slate-200 border-dashed">
          <div className="max-w-md mx-auto flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 mb-4 shadow-2xs">
              <Leaf className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              {search ? 'No matching analyses found' : 'No carbon analyses generated yet'}
            </h3>
            <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
              {search
                ? 'Try adjusting your search criteria.'
                : boqs.length === 0
                ? 'Generate a BOQ first (Module 2) - carbon analysis is calculated from BOQ material quantities.'
                : 'Select an existing BOQ to calculate its embodied carbon footprint.'}
            </p>
            <div className="mt-5">
              {boqs.length === 0 ? (
                <Link href="/boq/new">
                  <Button variant="primary" size="sm">
                    Generate BOQ First
                  </Button>
                </Link>
              ) : (
                <Link href="/carbon/new">
                  <Button
                    size="sm"
                    className="font-semibold shadow-xs bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700"
                    icon={<Plus className="w-4 h-4" />}
                  >
                    Run First Carbon Analysis
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </Card>
      ) : (
        <Card className="overflow-hidden bg-white border-slate-200/90 shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-mono text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4 font-semibold">Analysis Name &amp; Project</th>
                  <th className="py-3 px-4 font-semibold">Location</th>
                  <th className="py-3 px-4 font-semibold text-right">Total Embodied Carbon</th>
                  <th className="py-3 px-4 font-semibold text-right">Intensity</th>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {filtered.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50/80 transition-colors group">
                    <td className="py-3.5 px-4">
                      <Link href={`/carbon/${a.id}`} className="block">
                        <span className="font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                          {a.analysisName}
                        </span>
                        <span className="block text-[11px] text-slate-500 mt-0.5">
                          Project: {a.projectName}
                        </span>
                      </Link>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate max-w-[120px]">{a.location}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                      {a.totalEmbodiedCarbonTonnes.toLocaleString()} tCO₂e
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-emerald-700">
                      {a.carbonIntensityKgPerSqm.toLocaleString()} kgCO₂e/m²
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 font-mono text-[11px]">
                      {new Date(a.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Link href={`/carbon/${a.id}`}>
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs">
                            <span>Open</span>
                            <ArrowUpRight className="w-3.5 h-3.5 ml-1 text-slate-400 group-hover:text-slate-700" />
                          </Button>
                        </Link>
                        <button
                          type="button"
                          onClick={() => deleteAnalysis(a.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors cursor-pointer"
                          title="Delete Analysis"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
