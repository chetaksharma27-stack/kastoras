'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useBOQs } from '../../lib/store/boq-context';
import { useCarbonAnalyses } from '../../lib/store/carbon-context';
import { calculateEmbodiedCarbon } from '../../lib/carbon/calculator';
import { ArrowLeft, Leaf, MapPin, Layers } from 'lucide-react';

export function GenerateCarbonForm() {
  const router = useRouter();
  const { boqs } = useBOQs();
  const { saveAnalysis } = useCarbonAnalyses();
  const [selectedBOQId, setSelectedBOQId] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const selectedBOQ = boqs.find((b) => b.id === selectedBOQId);

  const handleGenerate = () => {
    if (!selectedBOQ) return;
    setIsGenerating(true);
    const analysis = calculateEmbodiedCarbon(selectedBOQ);
    saveAnalysis(analysis);
    router.push(`/carbon/${analysis.id}`);
  };

  if (boqs.length === 0) {
    return (
      <Card className="p-12 text-center bg-white border-slate-200 max-w-2xl mx-auto border-dashed">
        <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 mb-4 mx-auto shadow-2xs">
          <Layers className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-slate-900">No BOQs Yet</h2>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
          Carbon analysis is calculated from a generated BOQ&apos;s material quantities. Generate a Module 2 BOQ first.
        </p>
        <div className="mt-5">
          <Link href="/boq/new">
            <Button variant="primary" size="sm">
              Generate BOQ
            </Button>
          </Link>
        </div>
      </Card>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16">
      <div className="flex items-center gap-3 pb-3 border-b border-slate-200">
        <Link
          href="/carbon"
          className="text-xs text-slate-500 hover:text-slate-900 flex items-center gap-1.5 transition-colors font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>All Analyses</span>
        </Link>
      </div>

      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
            M3
          </span>
          <Badge variant="emerald" className="font-mono text-xs">
            Run Embodied Carbon Analysis
          </Badge>
        </div>
        <h1 className="text-xl font-bold text-slate-900 mt-2">Select a BOQ to Analyze</h1>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">
          Every material quantity in the BOQ is matched against an emission factor and summed into total embodied carbon (kgCO₂e), reported both in total and per square metre of built-up area.
        </p>

        <div className="mt-5 space-y-2 max-h-80 overflow-y-auto pr-1">
          {boqs.map((boq) => (
            <button
              key={boq.id}
              type="button"
              onClick={() => setSelectedBOQId(boq.id)}
              className={`w-full text-left p-4 rounded-lg border transition-colors ${
                selectedBOQId === boq.id
                  ? 'border-emerald-400 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                  : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-bold text-slate-900">{boq.boqName}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">Project: {boq.projectName}</p>
                  <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-500">
                    <MapPin className="w-3 h-3" />
                    <span>{boq.location}</span>
                    <span className="text-slate-300">•</span>
                    <span className="font-mono">{boq.items.length} items</span>
                  </div>
                </div>
                <span className="font-mono text-sm font-bold text-slate-900 shrink-0">
                  ₹{boq.totalAmount.toLocaleString()}
                </span>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100">
          <Button
            size="md"
            className="w-full font-semibold bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700"
            icon={<Leaf className="w-4 h-4" />}
            disabled={!selectedBOQId || isGenerating}
            onClick={handleGenerate}
          >
            {isGenerating ? 'Calculating...' : 'Calculate Embodied Carbon'}
          </Button>
        </div>
      </Card>
    </div>
  );
}
