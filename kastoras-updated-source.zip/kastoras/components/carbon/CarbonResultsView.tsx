'use client';

import React from 'react';
import Link from 'next/link';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useCarbonAnalyses } from '../../lib/store/carbon-context';
import { ArrowLeft, MapPin, Calendar, Printer, Info, AlertTriangle, Leaf } from 'lucide-react';

interface CarbonResultsViewProps {
  id: string;
}

export function CarbonResultsView({ id }: CarbonResultsViewProps) {
  const { getAnalysisById } = useCarbonAnalyses();
  const analysis = getAnalysisById(id);

  if (!analysis) {
    return (
      <Card className="p-12 text-center bg-white border-slate-200 max-w-2xl mx-auto">
        <h2 className="text-lg font-bold text-slate-900">Analysis Not Found</h2>
        <p className="text-xs text-slate-500 mt-1">
          The requested carbon analysis was not found in your workspace.
        </p>
        <div className="mt-4">
          <Link href="/carbon">
            <Button variant="outline" size="sm" icon={<ArrowLeft className="w-4 h-4" />}>
              Back to Analyses
            </Button>
          </Link>
        </div>
      </Card>
    );
  }

  const excludedItems = analysis.items.filter((i) => i.excluded);
  const includedItems = analysis.items.filter((i) => !i.excluded);

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16 print:p-0 print:max-w-none">
      {/* Top bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200 print:hidden">
        <Link
          href="/carbon"
          className="text-xs text-slate-500 hover:text-slate-900 flex items-center gap-1.5 transition-colors font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>All Analyses</span>
        </Link>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => window.print()}
          icon={<Printer className="w-3.5 h-3.5" />}
        >
          Print Report
        </Button>
      </div>

      {/* Header */}
      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
                M3
              </span>
              <Badge variant="emerald" className="font-mono text-xs">
                Embodied Carbon Analysis · Stages A1-A3
              </Badge>
              <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {new Date(analysis.createdAt).toLocaleDateString()}
              </span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              {analysis.analysisName}
            </h1>
            <div className="flex flex-wrap items-center gap-4 mt-2 text-xs text-slate-600">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{analysis.location}</span>
              </span>
              <span className="font-mono text-slate-400">
                Built-up:{' '}
                <strong className="text-slate-900">
                  {analysis.totalBuiltUpAreaSqm.toLocaleString()} m²
                </strong>
              </span>
            </div>
          </div>

          <div className="p-4 bg-emerald-900 text-white rounded-xl text-left md:text-right shrink-0 border border-emerald-800">
            <span className="text-[10px] font-mono text-emerald-300 uppercase tracking-wider block font-semibold">
              Total Embodied Carbon
            </span>
            <span className="text-2xl sm:text-3xl font-bold font-mono text-white block mt-0.5">
              {analysis.totalEmbodiedCarbonTonnes.toLocaleString()} tCO₂e
            </span>
            <span className="text-xs font-mono text-emerald-300 block mt-1">
              {analysis.carbonIntensityKgPerSqm.toLocaleString()}{' '}
              <span className="text-emerald-400/80">kgCO₂e / m²</span>
            </span>
          </div>
        </div>
      </Card>

      {/* Trade breakdown */}
      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
          <Leaf className="w-5 h-5 text-emerald-600" />
          <h2 className="text-base font-bold text-slate-900">Trade-wise Emission Breakdown</h2>
        </div>
        <div className="space-y-2.5">
          {analysis.tradeBreakdown.map((t) => (
            <div key={t.trade}>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">{t.trade}</span>
                <span className="font-mono text-slate-500">
                  {t.kgCO2e.toLocaleString()} kgCO₂e ({t.percent}%)
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${t.percent}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Line items table */}
      <Card className="overflow-hidden bg-white border-slate-200/90 shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-mono text-slate-600 uppercase tracking-wider">
                <th className="py-3 px-3 font-semibold">Item Code</th>
                <th className="py-3 px-3 font-semibold">Description</th>
                <th className="py-3 px-3 font-semibold">Trade</th>
                <th className="py-3 px-3 font-semibold text-right">Quantity</th>
                <th className="py-3 px-3 font-semibold text-right">Emission Factor</th>
                <th className="py-3 px-3 font-semibold text-right">Total kgCO₂e</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {includedItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-700">
                    {item.itemCode}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-900 max-w-[240px]">
                    {item.description}
                  </td>
                  <td className="py-2.5 px-3 text-[11px] text-slate-500">{item.trade}</td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-800">
                    {item.quantity.toLocaleString()} {item.unit}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-500">
                    {item.emissionFactor} {item.emissionFactorUnit}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                    {item.totalEmissionsKg.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-emerald-900 text-white font-mono font-bold text-sm">
                <td colSpan={5} className="py-3 px-3 uppercase tracking-wider">
                  Total Embodied Carbon
                </td>
                <td className="py-3 px-3 text-right text-emerald-300">
                  {analysis.totalEmbodiedCarbonKg.toLocaleString()} kg
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      {/* Method & exclusions */}
      <Card className="p-6 bg-white border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Info className="w-5 h-5 text-emerald-600" />
          <h2 className="text-base font-bold text-slate-900">Calculation Method &amp; Exclusions</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-600 leading-relaxed">
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 text-xs">Formula Applied</h3>
            <ul className="space-y-1.5 list-disc pl-4">
              <li>
                <strong>Line emissions:</strong> Quantity × Emission Factor. Items measured in MT (reinforcement rebar, structural steel) are converted to kg before applying their per-kg factor.
              </li>
              <li>
                <strong>Carbon intensity:</strong> Total Embodied Carbon (kg) ÷ Built-up Area (m²).
              </li>
              <li>
                <strong>Scope:</strong> Stages A1-A3 (cradle-to-gate: raw material extraction, transport, manufacturing) only. Construction (A4-A5), use-phase, and end-of-life stages are not included.
              </li>
            </ul>
          </div>
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 text-xs">Excluded Items</h3>
            {excludedItems.length === 0 ? (
              <p className="text-xs text-slate-500">
                Temporary works (formwork/shuttering) are excluded from embodied carbon as they are reused across multiple pours rather than remaining in the finished structure. No other items were excluded.
              </p>
            ) : (
              <ul className="space-y-1.5 list-disc pl-4">
                {excludedItems.map((item) => (
                  <li key={item.id}>
                    <strong>{item.itemCode}</strong> - {item.exclusionReason}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="mt-4 p-4 rounded-xl bg-amber-50/80 border border-amber-200/80 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900 leading-relaxed">
            <p className="font-bold">Engineering Transparency Notice:</p>
            <p className="mt-0.5">
              Emission factors used here are illustrative MVP benchmarks, not verified Environmental Product Declarations (EPDs). For LEED/GRIHA compliance-grade reporting, replace these with regional EPD or Ecoinvent/ICE Database values matched to actual sourced materials.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
