import React from 'react';
import { AppLayout } from '../../components/layout/AppLayout';
import { BOQList } from '../../components/boq/BOQList';

export default function BoqPage() {
  return (
    <AppLayout>
      <BOQList />
    </AppLayout>
  );
}
