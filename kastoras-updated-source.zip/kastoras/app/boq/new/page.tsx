import React from 'react';
import { AppLayout } from '../../../components/layout/AppLayout';
import { GenerateBOQForm } from '../../../components/boq/GenerateBOQForm';

export default function NewBoqPage() {
  return (
    <AppLayout>
      <GenerateBOQForm />
    </AppLayout>
  );
}
