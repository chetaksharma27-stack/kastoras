import React from 'react';
import { AppLayout } from '../../../components/layout/AppLayout';
import { BOQResultsView } from '../../../components/boq/BOQResultsView';

export default async function BoqDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  return (
    <AppLayout>
      <BOQResultsView id={id} />
    </AppLayout>
  );
}
