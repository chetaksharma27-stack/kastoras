import React from 'react';
import { AppLayout } from '../../../components/layout/AppLayout';
import { CarbonResultsView } from '../../../components/carbon/CarbonResultsView';

export default async function CarbonDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  return (
    <AppLayout>
      <CarbonResultsView id={id} />
    </AppLayout>
  );
}
