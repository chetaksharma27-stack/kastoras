import React from 'react';
import { AppLayout } from '../../../components/layout/AppLayout';
import { GenerateCarbonForm } from '../../../components/carbon/GenerateCarbonForm';

export default function NewCarbonPage() {
  return (
    <AppLayout>
      <GenerateCarbonForm />
    </AppLayout>
  );
}
