import React from 'react';
import { AppLayout } from '../../components/layout/AppLayout';
import { CarbonList } from '../../components/carbon/CarbonList';

export default function CarbonPage() {
  return (
    <AppLayout>
      <CarbonList />
    </AppLayout>
  );
}
